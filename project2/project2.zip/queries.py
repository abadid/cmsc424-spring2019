queries = ["" for i in range(0, 3)]

### 1.
queries[1] = """
"""

### 2.
queries[2] = """
"""
